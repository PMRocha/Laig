#include "Transformation.h"


Transformation::Transformation(void)
{
}


Transformation::~Transformation(void)
{
}

void Transformation::apply()
{
}
