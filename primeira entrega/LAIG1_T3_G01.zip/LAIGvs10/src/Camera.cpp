/*
 * Cameras.cpp
 *
 *  Created on: 23/09/2013
 *      Author: DEMO
 */

#include "Camera.h"



Camera::~Camera() {
	// TODO Auto-generated destructor stub
}

Camera::Camera(bool activated)
{
	this->activated=activated;
}
