#ifndef _POINT_H_
#define _POINT_H_
#include "CGFobject.h"
#include <vector>
#include <iostream>
#include <math.h>
using namespace std;

struct Point{
	float x;
	float y;
	float z;
};

#endif